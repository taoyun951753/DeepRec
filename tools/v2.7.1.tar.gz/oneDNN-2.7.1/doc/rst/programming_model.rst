Programming Model
#####################

.. toctree::
   :maxdepth: 1

   dev_guide_basic_concepts
   page_getting_started_cpp
   page_memory_format_propagation_cpp
   dev_guide_inference_and_training_aspects
   dev_guide_attributes
   dev_guide_data_types
   page_cross_engine_reorder_cpp
   dev_guide_c_and_cpp_apis
   interop_with_dpcpp_and_opencl